-- MySQL dump 10.13  Distrib 5.7.41, for Linux (x86_64)
--
-- Host: localhost    Database: my_first_db
-- ------------------------------------------------------
-- Server version	5.7.41-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ma_article`
--

DROP TABLE IF EXISTS `ma_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ma_article` (
  `article_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) DEFAULT NULL,
  `sub_title` varchar(1000) DEFAULT NULL,
  `summary` longblob,
  `content` longblob,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `photo_id` bigint(20) unsigned DEFAULT NULL,
  `allow_comments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ma_article`
--

LOCK TABLES `ma_article` WRITE;
/*!40000 ALTER TABLE `ma_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `ma_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ma_object_article`
--

DROP TABLE IF EXISTS `ma_object_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ma_object_article` (
  `article_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`article_id`,`object_type_id`,`object_id`),
  KEY `article_id` (`article_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ma_object_article`
--

LOCK TABLES `ma_object_article` WRITE;
/*!40000 ALTER TABLE `ma_object_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `ma_object_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mact_action`
--

DROP TABLE IF EXISTS `mact_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mact_action` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mact_action`
--

LOCK TABLES `mact_action` WRITE;
/*!40000 ALTER TABLE `mact_action` DISABLE KEYS */;
INSERT INTO `mact_action` VALUES (1,'like','2021-09-13 09:53:40','2021-09-13 09:53:40'),(2,'unlike','2021-09-13 09:53:40','2021-09-13 09:53:40'),(3,'rating','2021-09-13 09:53:40','2021-09-13 09:53:40');
/*!40000 ALTER TABLE `mact_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mact_user_action`
--

DROP TABLE IF EXISTS `mact_user_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mact_user_action` (
  `user_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `time` bigint(20) unsigned NOT NULL,
  `value` varchar(100) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`action_id`,`object_type_id`,`object_id`,`time`),
  KEY `action_id` (`action_id`),
  KEY `object_type_id` (`object_type_id`,`object_id`),
  KEY `action_id_2` (`action_id`,`object_type_id`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mact_user_action`
--

LOCK TABLES `mact_user_action` WRITE;
/*!40000 ALTER TABLE `mact_user_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `mact_user_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mat_attachment`
--

DROP TABLE IF EXISTS `mat_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mat_attachment` (
  `attachment_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(100) NOT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mat_attachment`
--

LOCK TABLES `mat_attachment` WRITE;
/*!40000 ALTER TABLE `mat_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `mat_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mat_object_attachment`
--

DROP TABLE IF EXISTS `mat_object_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mat_object_attachment` (
  `attachment_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`attachment_id`,`object_type_id`,`object_id`),
  KEY `attachment_id` (`attachment_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mat_object_attachment`
--

LOCK TABLES `mat_object_attachment` WRITE;
/*!40000 ALTER TABLE `mat_object_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `mat_object_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mc_comment`
--

DROP TABLE IF EXISTS `mc_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mc_comment` (
  `comment_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `comment` longblob NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mc_comment`
--

LOCK TABLES `mc_comment` WRITE;
/*!40000 ALTER TABLE `mc_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `mc_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mc_object_comment`
--

DROP TABLE IF EXISTS `mc_object_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mc_object_comment` (
  `comment_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`comment_id`,`object_type_id`,`object_id`),
  KEY `comment_id` (`comment_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mc_object_comment`
--

LOCK TABLES `mc_object_comment` WRITE;
/*!40000 ALTER TABLE `mc_object_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `mc_object_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `me_event`
--

DROP TABLE IF EXISTS `me_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `me_event` (
  `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) DEFAULT NULL,
  `sub_title` varchar(1000) DEFAULT NULL,
  `description` longblob,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `photo_id` bigint(20) unsigned DEFAULT NULL,
  `allow_comments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `address` varchar(100) DEFAULT NULL,
  `zip_id` varchar(15) DEFAULT NULL,
  `locality` varchar(50) DEFAULT NULL,
  `country_id` bigint(20) unsigned DEFAULT NULL,
  `latitude` decimal(18,15) DEFAULT NULL,
  `longitude` decimal(18,15) DEFAULT NULL,
  `begin_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `me_event`
--

LOCK TABLES `me_event` WRITE;
/*!40000 ALTER TABLE `me_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `me_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `me_object_event`
--

DROP TABLE IF EXISTS `me_object_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `me_object_event` (
  `event_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`event_id`,`object_type_id`,`object_id`),
  KEY `event_id` (`event_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `me_object_event`
--

LOCK TABLES `me_object_event` WRITE;
/*!40000 ALTER TABLE `me_object_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `me_object_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mmenu_group`
--

DROP TABLE IF EXISTS `mmenu_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mmenu_group` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mmenu_group`
--

LOCK TABLES `mmenu_group` WRITE;
/*!40000 ALTER TABLE `mmenu_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `mmenu_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mmenu_item`
--

DROP TABLE IF EXISTS `mmenu_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mmenu_item` (
  `item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `previous_html` longblob NOT NULL,
  `next_html` longblob NOT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `group_id` (`group_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mmenu_item`
--

LOCK TABLES `mmenu_item` WRITE;
/*!40000 ALTER TABLE `mmenu_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `mmenu_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mmenu_object_group`
--

DROP TABLE IF EXISTS `mmenu_object_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mmenu_object_group` (
  `group_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`group_id`,`object_type_id`,`object_id`),
  KEY `group_id` (`group_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mmenu_object_group`
--

LOCK TABLES `mmenu_object_group` WRITE;
/*!40000 ALTER TABLE `mmenu_object_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `mmenu_object_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mmsg_message`
--

DROP TABLE IF EXISTS `mmsg_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mmsg_message` (
  `message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from_user_id` bigint(20) unsigned NOT NULL,
  `to_user_id` bigint(20) unsigned NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `content` longblob,
  `seen_date` timestamp NULL DEFAULT NULL,
  `from_user_status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `to_user_status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`message_id`,`from_user_id`,`to_user_id`),
  KEY `from_user_id` (`from_user_id`,`to_user_id`),
  KEY `from_user_status` (`from_user_status`,`to_user_status`),
  KEY `from_user_id_2` (`from_user_id`,`to_user_id`,`from_user_status`),
  KEY `from_user_id_3` (`from_user_id`,`to_user_id`,`to_user_status`),
  KEY `from_user_id_4` (`from_user_id`,`from_user_status`),
  KEY `to_user_id` (`to_user_id`,`to_user_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mmsg_message`
--

LOCK TABLES `mmsg_message` WRITE;
/*!40000 ALTER TABLE `mmsg_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `mmsg_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mo_object_type`
--

DROP TABLE IF EXISTS `mo_object_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mo_object_type` (
  `object_type_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`object_type_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mo_object_type`
--

LOCK TABLES `mo_object_type` WRITE;
/*!40000 ALTER TABLE `mo_object_type` DISABLE KEYS */;
INSERT INTO `mo_object_type` VALUES (1,'page','2021-09-13 09:53:38','2021-09-13 09:53:38'),(2,'module','2021-09-13 09:53:38','2021-09-13 09:53:38'),(3,'article','2021-09-13 09:53:38','2021-09-13 09:53:38'),(4,'objects_group','2021-09-13 09:53:38','2021-09-13 09:53:38'),(5,'action','2021-09-13 09:53:38','2021-09-13 09:53:38'),(6,'attachment','2021-09-13 09:53:38','2021-09-13 09:53:38'),(7,'comment','2021-09-13 09:53:38','2021-09-13 09:53:38'),(8,'menu','2021-09-13 09:53:38','2021-09-13 09:53:38'),(9,'tag','2021-09-13 09:53:38','2021-09-13 09:53:38'),(10,'user','2021-09-13 09:53:38','2021-09-13 09:53:38'),(11,'event','2021-09-13 09:53:38','2021-09-13 09:53:38'),(12,'quiz','2021-09-13 09:53:38','2021-09-13 09:53:38'),(13,'quiz_question','2021-09-13 09:53:38','2021-09-13 09:53:38'),(14,'quiz_answer','2021-09-13 09:53:38','2021-09-13 09:53:38'),(15,'menu_item','2021-09-13 09:53:38','2021-09-13 09:53:38');
/*!40000 ALTER TABLE `mo_object_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mog_object_objects_group`
--

DROP TABLE IF EXISTS `mog_object_objects_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mog_object_objects_group` (
  `objects_group_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`objects_group_id`,`object_type_id`,`object_id`),
  KEY `objects_group_id` (`objects_group_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mog_object_objects_group`
--

LOCK TABLES `mog_object_objects_group` WRITE;
/*!40000 ALTER TABLE `mog_object_objects_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `mog_object_objects_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mog_objects_group`
--

DROP TABLE IF EXISTS `mog_objects_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mog_objects_group` (
  `objects_group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object` longblob NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`objects_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mog_objects_group`
--

LOCK TABLES `mog_objects_group` WRITE;
/*!40000 ALTER TABLE `mog_objects_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `mog_objects_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mq_answer`
--

DROP TABLE IF EXISTS `mq_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mq_answer` (
  `answer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) unsigned NOT NULL,
  `title` varchar(1000) DEFAULT NULL,
  `description` longblob,
  `value` smallint(6) NOT NULL DEFAULT '1',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`answer_id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mq_answer`
--

LOCK TABLES `mq_answer` WRITE;
/*!40000 ALTER TABLE `mq_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `mq_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mq_object_question`
--

DROP TABLE IF EXISTS `mq_object_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mq_object_question` (
  `question_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`question_id`,`object_type_id`,`object_id`),
  KEY `question_id` (`question_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mq_object_question`
--

LOCK TABLES `mq_object_question` WRITE;
/*!40000 ALTER TABLE `mq_object_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `mq_object_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mq_question`
--

DROP TABLE IF EXISTS `mq_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mq_question` (
  `question_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) DEFAULT NULL,
  `description` longblob,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mq_question`
--

LOCK TABLES `mq_question` WRITE;
/*!40000 ALTER TABLE `mq_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `mq_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mq_user_answer`
--

DROP TABLE IF EXISTS `mq_user_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mq_user_answer` (
  `user_id` bigint(20) unsigned NOT NULL,
  `answer_id` bigint(20) unsigned NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`answer_id`),
  KEY `answer_id` (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mq_user_answer`
--

LOCK TABLES `mq_user_answer` WRITE;
/*!40000 ALTER TABLE `mq_user_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `mq_user_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mt_object_tag`
--

DROP TABLE IF EXISTS `mt_object_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mt_object_tag` (
  `tag_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`tag_id`,`object_type_id`,`object_id`),
  KEY `tag_id` (`tag_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mt_object_tag`
--

LOCK TABLES `mt_object_tag` WRITE;
/*!40000 ALTER TABLE `mt_object_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `mt_object_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mt_tag`
--

DROP TABLE IF EXISTS `mt_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mt_tag` (
  `tag_id` bigint(20) unsigned NOT NULL,
  `tag` varchar(200) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  KEY `tag_id` (`tag_id`,`tag`),
  KEY `tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mt_tag`
--

LOCK TABLES `mt_tag` WRITE;
/*!40000 ALTER TABLE `mt_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `mt_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_activity`
--

DROP TABLE IF EXISTS `mu_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_activity` (
  `activity_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_activity`
--

LOCK TABLES `mu_activity` WRITE;
/*!40000 ALTER TABLE `mu_activity` DISABLE KEYS */;
INSERT INTO `mu_activity` VALUES (1,'access','2021-09-13 09:53:38','2021-09-13 09:53:38'),(2,'write','2021-09-13 09:53:38','2021-09-13 09:53:38'),(3,'delete','2021-09-13 09:53:38','2021-09-13 09:53:38');
/*!40000 ALTER TABLE `mu_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_external_user`
--

DROP TABLE IF EXISTS `mu_external_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_external_user` (
  `external_user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `external_type_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: auth0',
  `social_network_type` varchar(255) NOT NULL DEFAULT '',
  `social_network_user_id` varchar(255) NOT NULL DEFAULT '',
  `token_1` longblob COMMENT 'auth0 code',
  `token_2` longblob COMMENT 'auth0 state',
  `token_3` longblob COMMENT 'some other token',
  `data` longblob COMMENT 'returned json user data',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`external_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_external_user`
--

LOCK TABLES `mu_external_user` WRITE;
/*!40000 ALTER TABLE `mu_external_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `mu_external_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_object_user`
--

DROP TABLE IF EXISTS `mu_object_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_object_user` (
  `user_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `group` bigint(20) unsigned DEFAULT NULL,
  `order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`object_type_id`,`object_id`),
  KEY `user_id` (`user_id`,`object_type_id`,`object_id`,`group`),
  KEY `object_type_id` (`object_type_id`,`object_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_object_user`
--

LOCK TABLES `mu_object_user` WRITE;
/*!40000 ALTER TABLE `mu_object_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `mu_object_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_user`
--

DROP TABLE IF EXISTS `mu_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_user` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `security_question_1` varchar(255) DEFAULT NULL,
  `security_answer_1` varchar(255) DEFAULT NULL,
  `security_question_2` varchar(255) DEFAULT NULL,
  `security_answer_2` varchar(255) DEFAULT NULL,
  `security_question_3` varchar(255) DEFAULT NULL,
  `security_answer_3` varchar(255) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `username` (`username`,`password`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_user`
--

LOCK TABLES `mu_user` WRITE;
/*!40000 ALTER TABLE `mu_user` DISABLE KEYS */;
INSERT INTO `mu_user` VALUES (1,'admin','admin','admin@admin.com','Admin',0,'','','','','','','2021-09-13 13:27:31','2021-09-13 13:27:31');
/*!40000 ALTER TABLE `mu_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_user_activity_object`
--

DROP TABLE IF EXISTS `mu_user_activity_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_user_activity_object` (
  `thread_id` varchar(20) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `activity_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `time` bigint(20) unsigned NOT NULL,
  `extra` longblob COMMENT 'This is to write some other info like the correspondent parameters, etc...',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`thread_id`,`user_id`,`activity_id`,`object_type_id`,`object_id`,`time`),
  KEY `user_id` (`user_id`),
  KEY `activity_id` (`activity_id`),
  KEY `object_type_id` (`object_type_id`,`object_id`),
  KEY `user_id_2` (`user_id`,`activity_id`,`object_type_id`,`object_id`),
  KEY `activity_id_2` (`activity_id`,`object_type_id`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_user_activity_object`
--

LOCK TABLES `mu_user_activity_object` WRITE;
/*!40000 ALTER TABLE `mu_user_activity_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `mu_user_activity_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_user_environment`
--

DROP TABLE IF EXISTS `mu_user_environment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_user_environment` (
  `user_id` bigint(20) unsigned NOT NULL,
  `environment_id` bigint(20) unsigned NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`environment_id`),
  KEY `environment_id` (`environment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_user_environment`
--

LOCK TABLES `mu_user_environment` WRITE;
/*!40000 ALTER TABLE `mu_user_environment` DISABLE KEYS */;
/*!40000 ALTER TABLE `mu_user_environment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_user_session`
--

DROP TABLE IF EXISTS `mu_user_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_user_session` (
  `username` varchar(50) NOT NULL,
  `environment_id` bigint(20) unsigned NOT NULL,
  `session_id` varchar(200) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `logged_status` tinyint(1) NOT NULL DEFAULT '0',
  `login_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `login_ip` varchar(100) NOT NULL,
  `logout_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `logout_ip` varchar(100) NOT NULL DEFAULT '',
  `failed_login_attempts` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `failed_login_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `failed_login_ip` varchar(100) NOT NULL,
  `captcha` varchar(50) NOT NULL DEFAULT '',
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`username`,`environment_id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `environment_id` (`environment_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_user_session`
--

LOCK TABLES `mu_user_session` WRITE;
/*!40000 ALTER TABLE `mu_user_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `mu_user_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_user_type`
--

DROP TABLE IF EXISTS `mu_user_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_user_type` (
  `user_type_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_type_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_user_type`
--

LOCK TABLES `mu_user_type` WRITE;
/*!40000 ALTER TABLE `mu_user_type` DISABLE KEYS */;
INSERT INTO `mu_user_type` VALUES (1,'public','2021-09-13 09:53:38','2021-09-13 09:53:38'),(2,'admin','2021-09-13 09:53:38','2021-09-13 09:53:38'),(3,'regular','2021-09-13 09:53:38','2021-09-13 09:53:38');
/*!40000 ALTER TABLE `mu_user_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_user_type_activity_object`
--

DROP TABLE IF EXISTS `mu_user_type_activity_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_user_type_activity_object` (
  `user_type_id` bigint(20) unsigned NOT NULL,
  `activity_id` bigint(20) unsigned NOT NULL,
  `object_type_id` bigint(20) unsigned NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_type_id`,`activity_id`,`object_type_id`,`object_id`),
  KEY `user_type_id` (`user_type_id`),
  KEY `activity_id` (`activity_id`),
  KEY `object_type_id` (`object_type_id`,`object_id`),
  KEY `activity_id_2` (`activity_id`,`object_type_id`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_user_type_activity_object`
--

LOCK TABLES `mu_user_type_activity_object` WRITE;
/*!40000 ALTER TABLE `mu_user_type_activity_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `mu_user_type_activity_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mu_user_user_type`
--

DROP TABLE IF EXISTS `mu_user_user_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mu_user_user_type` (
  `user_id` bigint(20) unsigned NOT NULL,
  `user_type_id` bigint(20) unsigned NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`user_type_id`),
  KEY `user_type_id` (`user_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mu_user_user_type`
--

LOCK TABLES `mu_user_user_type` WRITE;
/*!40000 ALTER TABLE `mu_user_user_type` DISABLE KEYS */;
INSERT INTO `mu_user_user_type` VALUES (1,2,'2021-09-13 13:27:39','2021-09-13 13:27:39');
/*!40000 ALTER TABLE `mu_user_user_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mwp_worker`
--

DROP TABLE IF EXISTS `mwp_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mwp_worker` (
  `worker_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(2048) DEFAULT NULL,
  `args` longblob,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: to parse; 1: being parsed; 2: parsed/closed; 3: failed',
  `thread_id` varchar(100) DEFAULT NULL,
  `begin_time` bigint(20) DEFAULT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `failed_attempts` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `description` longblob,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`worker_id`),
  KEY `status` (`status`,`begin_time`,`failed_attempts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mwp_worker`
--

LOCK TABLES `mwp_worker` WRITE;
/*!40000 ALTER TABLE `mwp_worker` DISABLE KEYS */;
/*!40000 ALTER TABLE `mwp_worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mz_city`
--

DROP TABLE IF EXISTS `mz_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mz_city` (
  `city_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`city_id`),
  KEY `state_id` (`state_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mz_city`
--

LOCK TABLES `mz_city` WRITE;
/*!40000 ALTER TABLE `mz_city` DISABLE KEYS */;
/*!40000 ALTER TABLE `mz_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mz_country`
--

DROP TABLE IF EXISTS `mz_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mz_country` (
  `country_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`country_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mz_country`
--

LOCK TABLES `mz_country` WRITE;
/*!40000 ALTER TABLE `mz_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `mz_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mz_state`
--

DROP TABLE IF EXISTS `mz_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mz_state` (
  `state_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`state_id`),
  KEY `country_id` (`country_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mz_state`
--

LOCK TABLES `mz_state` WRITE;
/*!40000 ALTER TABLE `mz_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `mz_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mz_zip`
--

DROP TABLE IF EXISTS `mz_zip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mz_zip` (
  `zip_id` varchar(15) NOT NULL,
  `country_id` bigint(20) unsigned NOT NULL,
  `zone_id` bigint(20) unsigned NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`zip_id`,`country_id`),
  KEY `country_id` (`country_id`),
  KEY `zone_id` (`zone_id`),
  KEY `country_id_2` (`country_id`,`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mz_zip`
--

LOCK TABLES `mz_zip` WRITE;
/*!40000 ALTER TABLE `mz_zip` DISABLE KEYS */;
/*!40000 ALTER TABLE `mz_zip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mz_zone`
--

DROP TABLE IF EXISTS `mz_zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mz_zone` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city_id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`zone_id`),
  KEY `city_id` (`city_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mz_zone`
--

LOCK TABLES `mz_zone` WRITE;
/*!40000 ALTER TABLE `mz_zone` DISABLE KEYS */;
/*!40000 ALTER TABLE `mz_zone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school`
--

DROP TABLE IF EXISTS `school`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school` (
  `school_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school`
--

LOCK TABLES `school` WRITE;
/*!40000 ALTER TABLE `school` DISABLE KEYS */;
INSERT INTO `school` VALUES (1,'ESPAV'),(9,'Rainha'),(11,'New school');
/*!40000 ALTER TABLE `school` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `student_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,1,'D. Henrique'),(2,9,'D. João'),(3,1,'D. Maria');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher` (
  `teacher_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint(20) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher`
--

LOCK TABLES `teacher` WRITE;
/*!40000 ALTER TABLE `teacher` DISABLE KEYS */;
INSERT INTO `teacher` VALUES (1,9,'João Pinto',48),(2,1,'Ana Cristina',40),(3,1,'Jorge Aragão Silva',46),(7,1,'João Pinto',37),(8,1,'David Oliveira Silva',35),(9,9,'Lopez',49),(13,11,'New teacher name',35),(14,11,'Other Teacher',40);
/*!40000 ALTER TABLE `teacher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-06 14:56:37
